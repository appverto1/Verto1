import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const migration = readFileSync(
  'supabase/migrations/20260728020000_sales_modular_profitability_policy.sql',
  'utf8'
);
const sqlTest = readFileSync(
  'supabase/tests/20260728020000_sales_modular_profitability_policy_test.sql',
  'utf8'
);
const server = readFileSync('server.ts', 'utf8');
const engine = readFileSync(
  'src/utils/salesModularProposal.ts',
  'utf8'
);
const economics = readFileSync(
  'src/utils/salesModularEconomics.ts',
  'utf8'
);
const builder = readFileSync(
  'src/components/SalesModularProposalBuilder.tsx',
  'utf8'
);
const catalogPanel = readFileSync(
  'src/components/SalesPricingCatalogPanel.tsx',
  'utf8'
);

assert.match(
  migration,
  /add column if not exists profitability_policy jsonb/
);
assert.match(
  migration,
  /alter column profitability_policy drop not null/
);
assert.match(
  migration,
  /profitability_policy is null\s+or public\.sales_profitability_policy_valid_v1/
);
assert.doesNotMatch(
  migration,
  /update public\.sales_pricing_catalog_versions\s+set profitability_policy[\s\S]*where status in \('active','archived'\)/i,
  'migration não pode fazer backfill de catálogos publicados'
);
assert.match(
  migration,
  /where target\.id = created_id[\s\S]*target\.status = 'draft'/
);
assert.match(
  migration,
  /create trigger sales_pricing_catalog_profitability_publish_v1/
);
assert.match(
  migration,
  /jsonb_set\([\s\S]*'\{profitabilityPolicy\}'/
);
assert.match(
  migration,
  /clone_sales_pricing_catalog_version_v3/
);
assert.match(
  migration,
  /save_sales_pricing_catalog_draft_v3/
);
assert.match(
  migration,
  /publish_sales_pricing_catalog_version_v3/
);
assert.match(
  migration,
  /"clinicMinimumEbitdaMarginBasisPoints":6000/
);
assert.match(
  migration,
  /"recurringTargetEbitdaMarginBasisPoints":7000/
);
assert.match(
  migration,
  /"moduleMinimumIncrementalMarginBasisPoints":7500/
);
assert.match(
  migration,
  /"moduleTargetIncrementalMarginBasisPoints":8000/
);

assert.match(sqlTest, /\bbegin;/i);
assert.match(sqlTest, /\brollback;/i);
assert.match(sqlTest, /clone_sales_pricing_catalog_version_v3\(/);
assert.match(sqlTest, /save_sales_pricing_catalog_draft_v3\(/);
assert.match(sqlTest, /publish_sales_pricing_catalog_version_v3\(/);
assert.match(sqlTest, /PROFITABILITY_POLICY_MISSING_FROM_SNAPSHOT/);
assert.match(sqlTest, /HISTORICAL_SNAPSHOT_CHANGED/);
assert.match(sqlTest, /CHECKOUT_OR_ACTIVATION_CHANGED/);

assert.match(
  server,
  /profitabilityPolicy: validateSalesProfitabilityPolicy\([\s\S]*\? version\.profitability_policy\s*: null/
);
assert.match(server, /clone_sales_pricing_catalog_version_v3/);
assert.match(server, /save_sales_pricing_catalog_draft_v3/);
assert.match(server, /publish_sales_pricing_catalog_version_v3/);
assert.match(server, /PROPOSAL_MARGIN_POLICY_REVIEW_REQUIRED/);
assert.match(server, /MODULAR_CHECKOUT_MARGIN_POLICY_REVIEW_REQUIRED/);
assert.doesNotMatch(server, /PROPOSAL_EBITDA_POLICY_BLOCKED/);
assert.doesNotMatch(server, /MODULAR_CHECKOUT_EBITDA_POLICY_BLOCKED/);
assert.match(
  server,
  /const frozenResults =[\s\S]*const frozenReview = classifySalesProposalReview\(frozenResults\)/
);

assert.match(
  engine,
  /sharedPlatformCosts: profitabilityPolicy[\s\S]*'base_package'/
);
assert.match(
  engine,
  /stripeFixed: profitabilityPolicy[\s\S]*'base_package'/
);
assert.match(engine, /SALES_MODULAR_ECONOMICS_MODEL_VERSION/);
assert.match(engine, /economics\?\.requiresJustification/);
assert.match(engine, /CAPACITY_MARGIN_BELOW_75/);
assert.match(engine, /MODULE_MARGIN_BELOW_75/);
assert.match(engine, /POST_PROMOTION_MARGIN_BELOW_70/);
assert.match(engine, /ECONOMICS_INSUFFICIENT_DATA/);

assert.match(
  economics,
  /1 - targetEbitdaMargin|denominatorBasisPoints/
);
assert.match(economics, /calculateSalesDriverExpansion/);
assert.match(economics, /calculateSalesModuleEffect/);
assert.match(economics, /SALES_EXPANSION_DRIVER_BY_ITEM/);

assert.match(builder, /Economia da clínica/);
assert.match(builder, /Simular escala e módulos/);
assert.match(builder, /\[150, 160, 170, 200\]/);
assert.match(builder, /Apenas Verto Clínica/);
assert.match(builder, /Mín\. 60%/);
assert.match(builder, /Mín\. 80%/);
assert.match(catalogPanel, /Política de margem operacional atribuída/);
assert.match(catalogPanel, /Franquias e excedentes por driver/);
assert.match(catalogPanel, /margem operacional modular/);

console.log('salesProfitabilityPolicyVersioning.test.ts: OK');
