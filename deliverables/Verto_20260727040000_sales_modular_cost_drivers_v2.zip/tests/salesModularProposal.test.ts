import assert from 'node:assert/strict';
import {
  allocateSalesCents,
  calculateSalesModularProposal,
  recommendSalesPackageTier,
  type SalesModularProposalInput,
  type SalesPricingCatalogItem,
  type SalesPricingCatalogSnapshot,
  type SalesPricingCatalogTier,
  type SalesPricingCostModel
} from '../src/utils/salesModularProposal';
import {
  DEFAULT_MODULAR_COST_SETTINGS,
  MODULAR_COST_APPLICABILITY_BY_ITEM,
  emptySalesModularDriverConfig,
  hasExactRequiredDrivers,
  isValidModularCostSettings,
  modularCostCategoryApplies,
  requiredDirectCostFieldsForItem,
  validateModularCatalogForPublication,
  type SalesModularDriverConfig,
  type SalesModularDriverKey,
  type SalesModularProfile
} from '../src/utils/salesModularCostDrivers';
import type {
  SalesAssumptionSnapshot,
  SalesAssumptionValues
} from '../src/utils/salesProfitability';

const zeroCost = (
  itemId: string,
  overrides: Partial<SalesPricingCostModel> = {}
): SalesPricingCostModel => ({
  id: `cost-${itemId}`,
  itemId,
  version: 1,
  directFixedMonthlyCostCents: 0,
  directCostPerPatientCents: 0,
  directCostPerClinicCents: 0,
  directCostPerUsageUnitCents: 0,
  storageCostPerGbCents: 0,
  egressCostPerGbCents: 0,
  notificationCostPerUnitCents: 0,
  processingCostPerUnitCents: 0,
  otherVariableCostCents: 0,
  supportFixedMonthlyCostCents: 0,
  supportCostPerPatientCents: 0,
  operationalFixedMonthlyCostCents: 0,
  onboardingCostCents: 0,
  sharedCostAllocationWeight: itemId === 'core' ? 4 : 1,
  costSource: 'manual',
  sourceDetail: 'Valores explícitos do teste',
  effectiveAt: '2026-07-27T00:00:00.000Z',
  driverConfig: emptySalesModularDriverConfig(''),
  ...overrides
});

const completeDriverConfig = (
  itemKey: string,
  values: Partial<Record<SalesModularDriverKey, number>> = {},
  unitCostsCents: SalesModularDriverConfig['unitCostsCents'] = {}
): SalesModularDriverConfig => {
  const config = emptySalesModularDriverConfig(itemKey);
  for (const profile of ['light', 'standard', 'intensive'] as SalesModularProfile[]) {
    for (const driver of config.requiredDrivers) {
      config.profiles[profile][driver] = {
        value: values[driver] ?? 0,
        source: 'estimated',
        sourceDetail: `Driver ${driver} do teste`,
        effectiveAt: '2026-07-27T00:00:00.000Z',
        version: 1
      };
    }
  }
  config.unitCostsCents = {
    monthlyAbaSessions: 0,
    monthlyAbaRecords: 0,
    generatedDocuments: 0,
    financialReports: 0,
    recurringProcesses: 0,
    tissBatches: 0,
    tissXmlDocuments: 0,
    tissDocuments: 0,
    schoolParticipants: 0,
    onboardingHours: 0,
    ...unitCostsCents
  };
  return config;
};

const tier = (
  itemId: string,
  key: string,
  maximum: number | null,
  amount: number | null,
  sortOrder: number,
  metadata: Record<string, any> = {}
): SalesPricingCatalogTier => ({
  id: `${itemId}-${key}`,
  itemId,
  tierKey: key,
  publicName: `${key} ${maximum ?? 'custom'}`,
  minimumQuantity: maximum === null ? 101 : 1,
  maximumQuantity: maximum,
  includedQuantity: maximum,
  recurringAmountCents: amount,
  oneTimeAmountCents: null,
  sortOrder,
  isCustom: maximum === null,
  metadata
});

const item = (
  id: string,
  itemKey: string,
  publicName: string,
  pricingMode: SalesPricingCatalogItem['pricingMode'],
  tiers: SalesPricingCatalogTier[],
  recurringAmountCents: number | null,
  sortOrder: number,
  billingInterval: SalesPricingCatalogItem['billingInterval'] = 'monthly'
): SalesPricingCatalogItem => ({
  id,
  itemKey,
  publicName,
  internalName: publicName,
  description: `${publicName} para teste`,
  pricingMode,
  billingInterval,
  unitName: itemKey === 'insurance_tiss' ? 'guias/mês' : 'pacientes',
  includedQuantity: null,
  maximumQuantity: null,
  recurringAmountCents,
  oneTimeAmountCents: null,
  sortOrder,
  isRequired: itemKey === 'clinical_core',
  isPublic: true,
  isActive: true,
  compatibleBasePackages: [],
  metadata: {},
  tiers,
  costModel: zeroCost(id, {
    driverConfig: completeDriverConfig(itemKey)
  })
});

const coreTiers = [
  tier('core', 'up_to_10', 10, 19900, 10),
  tier('core', 'up_to_25', 25, 39900, 20),
  tier('core', 'up_to_50', 50, 69900, 30),
  tier('core', 'up_to_100', 100, 119900, 40),
  tier('core', 'custom', null, null, 50)
];
const agendaTiers = [
  tier('agenda', 'up_to_10', 10, 4900, 10),
  tier('agenda', 'up_to_25', 25, 7900, 20),
  tier('agenda', 'up_to_50', 50, 12900, 30),
  tier('agenda', 'up_to_100', 100, 19900, 40),
  tier('agenda', 'custom', null, null, 50)
];
const insuranceTiers = [
  tier('insurance', 'up_to_100', 100, 14900, 10),
  tier('insurance', 'up_to_500', 500, 29900, 20),
  tier('insurance', 'custom', null, null, 30)
];
const schoolTiers = [
  tier('school', 'up_to_10', 10, 5900, 10),
  tier('school', 'up_to_25', 25, 9900, 20),
  tier('school', 'up_to_50', 50, 14900, 30),
  tier('school', 'up_to_100', 100, 24900, 40),
  tier('school', 'custom', null, null, 50)
];
const storageTiers = [
  tier('storage', 'gb_1', null, 299, 10, { gigabytes: 1 }),
  {
    ...tier('storage', 'gb_5', null, 990, 20, { gigabytes: 5 }),
    isCustom: false,
    minimumQuantity: 1,
    includedQuantity: 5120
  },
  {
    ...tier('storage', 'gb_10', null, 1690, 30, { gigabytes: 10 }),
    isCustom: false,
    minimumQuantity: 1,
    includedQuantity: 10240
  }
];
storageTiers[0].isCustom = false;
storageTiers[0].minimumQuantity = 1;
storageTiers[0].includedQuantity = 1024;

const catalog: SalesPricingCatalogSnapshot = {
  id: 'catalog-v1',
  version: 1,
  name: 'Catálogo teste',
  status: 'active',
  effectiveAt: '2026-07-27T00:00:00.000Z',
  allocationSettings: {
    stripePercentage: 'net_revenue',
    stripeFixed: 'base_package',
    revenueTax: 'net_revenue',
    delinquency: 'net_revenue',
    sharedPlatformCosts: 'configured_weight',
    belowEbitda: 'configured_weight'
  },
  modularCostSettings: {
    ...DEFAULT_MODULAR_COST_SETTINGS,
    ownershipJustifications: {},
    usageProfiles: {
      light: {
        storageUtilizationBasisPoints: 2500,
        expectedEgressMultiplier: 0.5
      },
      standard: {
        storageUtilizationBasisPoints: 6000,
        expectedEgressMultiplier: 2
      },
      intensive: {
        storageUtilizationBasisPoints: 10000,
        expectedEgressMultiplier: 5
      }
    }
  },
  items: [
    item('core', 'clinical_core', 'Verto Clínica', 'package_limit', coreTiers, null, 10),
    item('agenda', 'appointments_communication', 'Agenda e Comunicação', 'package_limit', agendaTiers, null, 20),
    item('finance', 'financial_management', 'Financeiro e Gestão', 'flat_monthly', [], 9900, 30),
    item('insurance', 'insurance_tiss', 'Convênios e TISS', 'usage_tier', insuranceTiers, null, 40),
    item('school', 'school_management', 'Gestão Escolar', 'package_limit', schoolTiers, null, 50),
    item('storage', 'additional_storage', 'Armazenamento adicional', 'storage_block', storageTiers, null, 60),
    item('onboarding', 'onboarding', 'Implantação', 'one_time', [], null, 70, 'one_time')
  ]
};

const zeroValues: SalesAssumptionValues = {
  officialUnitAmountCents: 7990,
  stripeFeeBasisPoints: 0,
  stripeFixedFeeCents: 0,
  revenueTaxBasisPoints: 0,
  estimatedDelinquencyBasisPoints: 0,
  variablePatientCostCents: 0,
  variableClinicCostCents: 0,
  storageCostCents: 0,
  egressCostCents: 0,
  processingCostCents: 0,
  notificationCostCents: 0,
  otherVariableCostCents: 0,
  monthlySupportClinicCostCents: 0,
  supportPatientCostCents: 0,
  monthlyOperationalCostCents: 0,
  defaultOnboardingCostCents: 10000,
  commercialCommissionBasisPoints: 0,
  fixedMonthlyEligibleCostCents: 0,
  fixedAllocationMethod: 'none',
  fixedAllocationPatientCount: null,
  fixedAllocationClinicCount: null,
  customFixedAllocationCents: null,
  depreciationAmortizationCents: 0,
  financialExpensesCents: 0,
  profitTaxBasisPoints: 0,
  otherBelowEbitdaCents: 0,
  minimumMarginBasisPoints: 1000,
  healthyMarginBasisPoints: 3000,
  attentionMarginBasisPoints: 1000,
  usageProfiles: {}
};

const assumptions: SalesAssumptionSnapshot = {
  id: 'assumptions-v1',
  version: 1,
  name: 'Premissas teste',
  effectiveAt: '2026-07-27T00:00:00.000Z',
  values: zeroValues,
  sources: {},
  sourceDetails: {}
};

const proposal = (
  overrides: Partial<SalesModularProposalInput> = {}
): SalesModularProposalInput => ({
  patientQuantity: 17,
  expectedPatientQuantity12Months: 25,
  basePackageTierId: 'core-up_to_25',
  lines: [
    {
      itemKey: 'clinical_core',
      tierId: 'core-up_to_25',
      quantity: 17,
      itemDiscountBasisPoints: 0
    },
    {
      itemKey: 'appointments_communication',
      tierId: 'agenda-up_to_25',
      quantity: 17,
      itemDiscountBasisPoints: 0
    },
    {
      itemKey: 'financial_management',
      quantity: 1,
      itemDiscountBasisPoints: 0
    },
    {
      itemKey: 'additional_storage',
      tierId: 'storage-gb_5',
      quantity: 1,
      itemDiscountBasisPoints: 0
    }
  ],
  globalDiscountBasisPoints: 0,
  discountDurationMonths: 0,
  offerValidityDays: 14,
  usageProfile: 'standard',
  ...overrides
});

const tests: Array<{ name: string; fn: () => void }> = [];
const test = (name: string, fn: () => void) => tests.push({ name, fn });

test('recomenda a menor faixa para 8, 17, 42 e 87 pacientes', () => {
  assert.equal(recommendSalesPackageTier(catalog, 8)?.id, 'core-up_to_10');
  assert.equal(recommendSalesPackageTier(catalog, 17)?.id, 'core-up_to_25');
  assert.equal(recommendSalesPackageTier(catalog, 42)?.id, 'core-up_to_50');
  assert.equal(recommendSalesPackageTier(catalog, 87)?.id, 'core-up_to_100');
});

test('respeita todos os limites do pacote-base, inclusive personalizado', () => {
  for (const [patients, expectedTier] of [
    [1, 'core-up_to_10'],
    [10, 'core-up_to_10'],
    [11, 'core-up_to_25'],
    [25, 'core-up_to_25'],
    [26, 'core-up_to_50'],
    [50, 'core-up_to_50'],
    [51, 'core-up_to_100'],
    [100, 'core-up_to_100'],
    [101, 'core-custom']
  ] as const) {
    assert.equal(
      recommendSalesPackageTier(catalog, patients)?.id,
      expectedTier
    );
  }
});

test('calcula exatamente o exemplo de 17 pacientes em R$ 586,90', () => {
  const result = calculateSalesModularProposal(
    proposal(),
    catalog,
    assumptions
  );
  assert.equal(result.grossRecurringRevenueCents, 58_690);
  assert.equal(result.promotionalRecurringRevenueCents, 58_690);
  assert.equal(result.postPromotionRecurringRevenueCents, 58_690);
  assert.equal(result.lines.length, 4);
  assert.equal(
    result.lines.reduce(
      (sum, line) => sum + line.promotionalRecurringRevenueCents,
      0
    ),
    result.promotional.recurringRevenueCents
  );
});

test('preserva igualdade exata em centavos com descontos por item e global', () => {
  const discounted = proposal({
    globalDiscountBasisPoints: 333,
    discountDurationMonths: 7,
    lines: proposal().lines.map((line, index) => ({
      ...line,
      itemDiscountBasisPoints: index === 1 ? 777 : 0
    }))
  });
  const result = calculateSalesModularProposal(
    discounted,
    catalog,
    assumptions
  );
  assert.equal(
    result.lines.reduce((sum, line) => sum + line.itemDiscountCents, 0),
    result.itemDiscountCents
  );
  assert.equal(
    result.lines.reduce(
      (sum, line) => sum + line.allocatedGlobalDiscountCents,
      0
    ),
    result.globalDiscountCents
  );
  for (const field of [
    'directCostCents',
    'transactionAndTaxCostAllocatedCents',
    'sharedPlatformCostAllocatedCents',
    'contributionMarginCents',
    'ebitdaCents',
    'belowEbitdaCostAllocatedCents',
    'profitTaxAllocatedCents',
    'netIncomeCents'
  ] as const) {
    assert.equal(
      result.lines.reduce(
        (sum, line) => sum + Number(line.promotional[field]),
        0
      ),
      result.promotional[field]
    );
  }
});

test('rateia custos reais e compartilhados sem perder nenhum centavo', () => {
  const values: SalesAssumptionValues = {
    ...zeroValues,
    stripeFeeBasisPoints: 290,
    stripeFixedFeeCents: 39,
    revenueTaxBasisPoints: 600,
    estimatedDelinquencyBasisPoints: 125,
    variablePatientCostCents: 11,
    variableClinicCostCents: 503,
    storageCostCents: 107,
    egressCostCents: 53,
    processingCostCents: 89,
    notificationCostCents: 47,
    otherVariableCostCents: 31,
    monthlySupportClinicCostCents: 397,
    supportPatientCostCents: 13,
    monthlyOperationalCostCents: 701,
    fixedMonthlyEligibleCostCents: 1009,
    fixedAllocationMethod: 'custom',
    customFixedAllocationCents: 1009,
    depreciationAmortizationCents: 307,
    financialExpensesCents: 211,
    profitTaxBasisPoints: 1500,
    otherBelowEbitdaCents: 101
  };
  const costedCatalog: SalesPricingCatalogSnapshot = {
    ...catalog,
    items: catalog.items.map((catalogItem, index) => ({
      ...catalogItem,
      costModel: zeroCost(catalogItem.id, {
        driverConfig: catalogItem.costModel!.driverConfig,
        directFixedMonthlyCostCents: 101 + index,
        directCostPerPatientCents: 3,
        directCostPerClinicCents: 17,
        directCostPerUsageUnitCents: 2,
        storageCostPerGbCents: 5,
        egressCostPerGbCents: 7,
        notificationCostPerUnitCents: 1,
        processingCostPerUnitCents: 2,
        supportFixedMonthlyCostCents: 19,
        supportCostPerPatientCents: 2,
        operationalFixedMonthlyCostCents: 23,
        onboardingCostCents: 5000,
        sharedCostAllocationWeight: index + 1
      })
    }))
  };
  const result = calculateSalesModularProposal(
    proposal({
      globalDiscountBasisPoints: 333,
      discountDurationMonths: 9
    }),
    costedCatalog,
    { ...assumptions, values }
  );
  const expectedTransactionAndTax =
    Math.round(
      (result.promotional.recurringRevenueCents *
        Number(values.stripeFeeBasisPoints)) /
        10_000
    ) +
    Math.round(
      (result.promotional.recurringRevenueCents *
        Number(values.revenueTaxBasisPoints)) /
        10_000
    ) +
    Math.round(
      (result.promotional.recurringRevenueCents *
        Number(values.estimatedDelinquencyBasisPoints)) /
        10_000
    ) +
    Number(values.stripeFixedFeeCents);
  assert.equal(
    result.promotional.transactionAndTaxCostAllocatedCents,
    expectedTransactionAndTax
  );
  assert.equal(
    result.lines[0].promotional.transactionAndTaxCostAllocatedCents! >=
      Number(values.stripeFixedFeeCents),
    true
  );
  for (const period of ['promotional', 'postPromotion'] as const) {
    for (const field of [
      'netRevenueCents',
      'directCostCents',
      'transactionAndTaxCostAllocatedCents',
      'sharedPlatformCostAllocatedCents',
      'contributionMarginCents',
      'ebitdaCents',
      'belowEbitdaCostAllocatedCents',
      'profitTaxAllocatedCents',
      'netIncomeCents'
    ] as const) {
      assert.equal(
        result.lines.reduce(
          (sum, line) => sum + Number(line[period][field]),
          0
        ),
        field === 'netRevenueCents'
          ? result[period].recurringRevenueCents
          : result[period][field]
      );
    }
  }
  assert.notEqual(result.minimumRecommendedRecurringRevenueCents, null);
  assert.notEqual(result.maximumRecommendedDiscountBasisPoints, null);
});

test('atribui deterministicamente o residuo ao pacote-base', () => {
  assert.deepEqual(allocateSalesCents(10, [1, 1, 1], 0), [4, 3, 3]);
  assert.deepEqual(allocateSalesCents(5, [0, 0, 0], 1), [0, 5, 0]);
});

test('nao transforma custo indisponivel em zero', () => {
  const unavailableCatalog: SalesPricingCatalogSnapshot = {
    ...catalog,
    items: catalog.items.map((catalogItem) =>
      catalogItem.itemKey === 'financial_management'
        ? {
            ...catalogItem,
            costModel: {
              ...catalogItem.costModel!,
              costSource: 'unavailable',
              directFixedMonthlyCostCents: null
            }
          }
        : catalogItem
    )
  };
  const result = calculateSalesModularProposal(
    proposal(),
    unavailableCatalog,
    assumptions
  );
  assert.ok(result.missingCosts.includes('Financeiro e Gestão'));
  assert.equal(result.promotional.directCostCents, null);
  assert.equal(result.promotional.ebitdaCents, null);
  assert.equal(result.rating, 'insufficient_data');
});

test('aceita todos os modulos, uso por guia e multiplos blocos de armazenamento', () => {
  const result = calculateSalesModularProposal(
    proposal({
      lines: [
        {
          itemKey: 'clinical_core',
          tierId: 'core-up_to_25',
          quantity: 17
        },
        {
          itemKey: 'appointments_communication',
          tierId: 'agenda-up_to_25',
          quantity: 17
        },
        { itemKey: 'financial_management', quantity: 1 },
        {
          itemKey: 'insurance_tiss',
          tierId: 'insurance-up_to_500',
          quantity: 240
        },
        {
          itemKey: 'school_management',
          tierId: 'school-up_to_25',
          quantity: 17
        },
        {
          itemKey: 'additional_storage',
          tierId: 'storage-gb_1',
          quantity: 2
        },
        {
          itemKey: 'additional_storage',
          tierId: 'storage-gb_5',
          quantity: 3
        },
        {
          itemKey: 'onboarding',
          quantity: 1,
          customOneTimeAmountCents: 15000
        }
      ]
    }),
    catalog,
    assumptions
  );
  assert.equal(result.lines.length, 8);
  assert.equal(result.grossRecurringRevenueCents, 101_068);
  assert.equal(result.oneTimeRevenueCents, 15_000);
  assert.equal(
    result.lines.filter((line) => line.itemKey === 'additional_storage').length,
    2
  );
  assert.equal(
    result.lines.find((line) => line.itemKey === 'insurance_tiss')?.quantity,
    240
  );
});

test('permite item gratuito e pacote personalizado autorizado', () => {
  const freeResult = calculateSalesModularProposal(
    proposal({
      lines: proposal().lines.map((line) =>
        line.itemKey === 'financial_management'
          ? { ...line, itemDiscountBasisPoints: 10_000 }
          : line
      )
    }),
    catalog,
    assumptions
  );
  assert.equal(
    freeResult.lines.find(
      (line) => line.itemKey === 'financial_management'
    )?.postPromotionRecurringRevenueCents,
    0
  );

  const customResult = calculateSalesModularProposal(
    proposal({
      patientQuantity: 101,
      expectedPatientQuantity12Months: 130,
      basePackageTierId: 'core-custom',
      lines: [
        {
          itemKey: 'clinical_core',
          tierId: 'core-custom',
          quantity: 101,
          customRecurringAmountCents: 150_000
        }
      ]
    }),
    catalog,
    assumptions
  );
  assert.equal(customResult.basePackage.limitQuantity, null);
  assert.equal(customResult.grossRecurringRevenueCents, 150_000);
});

test('rejeita desconto invalido com codigo comercial especifico', () => {
  assert.throws(
    () =>
      calculateSalesModularProposal(
        proposal({ globalDiscountBasisPoints: 10_001 }),
        catalog,
        assumptions
      ),
    /PRICING_INVALID_DISCOUNT/
  );
  assert.throws(
    () =>
      calculateSalesModularProposal(
        proposal({
          lines: proposal().lines.map((line, index) => ({
            ...line,
            itemDiscountBasisPoints: index === 0 ? 10_001 : 0
          }))
        }),
        catalog,
        assumptions
      ),
    /PRICING_INVALID_DISCOUNT/
  );
});

test('margem negativa exige justificativa e nao e bloqueada pelo motor', () => {
  const expensiveCatalog: SalesPricingCatalogSnapshot = {
    ...catalog,
    modularCostSettings: {
      ...catalog.modularCostSettings,
      ownership: {
        ...catalog.modularCostSettings.ownership,
        fixedMonthlyEligibleCost: 'item_direct'
      }
    },
    items: catalog.items.map((catalogItem) =>
      catalogItem.itemKey === 'clinical_core'
        ? {
            ...catalogItem,
            costModel: zeroCost(catalogItem.id, {
              driverConfig: catalogItem.costModel!.driverConfig,
              directFixedMonthlyCostCents: 100_000
            })
          }
        : catalogItem
    )
  };
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    expensiveCatalog,
    assumptions
  );
  assert.equal(result.rating, 'not_recommended');
  assert.equal(result.requiresJustification, true);
  assert.ok(
    result.lines[0].warnings.includes('EBITDA promocional negativo.')
  );
});

test('rejeita pacote-base menor que a quantidade da clinica', () => {
  assert.throws(
    () =>
      calculateSalesModularProposal(
        proposal({ basePackageTierId: 'core-up_to_10' }),
        catalog,
        assumptions
      ),
    /PRICING_PACKAGE_LIMIT_EXCEEDED/
  );
});

test('permite selecionar faixa superior à recomendada', () => {
  const result = calculateSalesModularProposal(
    proposal({
      basePackageTierId: 'core-up_to_50',
      lines: [
        {
          itemKey: 'clinical_core',
          tierId: 'core-up_to_50',
          quantity: 17
        }
      ]
    }),
    catalog,
    assumptions
  );
  assert.equal(result.basePackage.limitQuantity, 50);
  assert.equal(result.basePackage.availableQuantity, 33);
  assert.equal(result.grossRecurringRevenueCents, 69_900);
});

test('contabiliza implantacao uma unica vez nos horizontes', () => {
  const input = proposal({
    lines: [
      ...proposal().lines,
      {
        itemKey: 'onboarding',
        quantity: 1,
        itemDiscountBasisPoints: 0,
        customOneTimeAmountCents: 10000
      }
    ]
  });
  const result = calculateSalesModularProposal(input, catalog, assumptions);
  assert.equal(result.oneTimeRevenueCents, 10000);
  assert.equal(result.oneTimeDirectCostCents, 0);
  assert.equal(result.oneTimeContributionMarginCents, 10000);
  assert.equal(
    result.horizons['12'].ebitdaCents,
    Number(result.promotional.ebitdaCents) * 12 + 10000
  );
  assert.equal(
    result.horizons['24'].ebitdaCents,
    Number(result.promotional.ebitdaCents) * 24 + 10000
  );
});

test('parcela implantacao somente na projecao comercial', () => {
  const input = proposal({
    onboardingInstallments: 24,
    lines: [
      ...proposal().lines,
      {
        itemKey: 'onboarding',
        quantity: 1,
        itemDiscountBasisPoints: 0,
        customOneTimeAmountCents: 12000
      }
    ]
  });
  const result = calculateSalesModularProposal(input, catalog, assumptions);
  assert.equal(result.oneTimeRevenueCents, 12000);
  assert.equal(result.horizons['12'].oneTimeRevenueCents, 6000);
  assert.equal(result.horizons['24'].oneTimeRevenueCents, 12000);
  assert.equal(result.horizons['36'].oneTimeRevenueCents, 12000);
  assert.equal(
    result.horizons['12'].ebitdaCents,
    Number(result.promotional.ebitdaCents) * 12 + 6000
  );
});

const withCostModel = (
  itemKey: string,
  overrides: Partial<SalesPricingCostModel>,
  driverValues: Partial<Record<SalesModularDriverKey, number>> = {},
  unitCosts: SalesModularDriverConfig['unitCostsCents'] = {}
): SalesPricingCatalogSnapshot => ({
  ...catalog,
  items: catalog.items.map((catalogItem) =>
    catalogItem.itemKey === itemKey
      ? {
          ...catalogItem,
          costModel: zeroCost(catalogItem.id, {
            driverConfig: completeDriverConfig(
              itemKey,
              driverValues,
              unitCosts
            ),
            ...overrides
          })
        }
      : catalogItem
  )
});

test('propriedade item_direct impede dupla contabilizacao da premissa geral', () => {
  const directCatalog = withCostModel('clinical_core', {
    directCostPerPatientCents: 50
  });
  const withSharedValue = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    directCatalog,
    {
      ...assumptions,
      values: { ...zeroValues, variablePatientCostCents: 100 }
    }
  );
  const withoutSharedValue = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    directCatalog,
    assumptions
  );
  assert.equal(
    withSharedValue.promotional.totalEstimatedCostCents,
    withoutSharedValue.promotional.totalEstimatedCostCents
  );
  assert.equal(withSharedValue.possibleDuplicateCosts.length, 0);
});

test('propriedade shared ignora o valor direto e contabiliza a premissa uma vez', () => {
  const sharedCatalog = withCostModel('clinical_core', {
    directCostPerPatientCents: 50
  });
  sharedCatalog.modularCostSettings = {
    ...sharedCatalog.modularCostSettings,
    ownership: {
      ...sharedCatalog.modularCostSettings.ownership,
      variablePatientCost: 'shared'
    },
    ownershipJustifications: {
      variablePatientCost: 'Valor direto mantido apenas para auditoria durante a transicao.'
    }
  };
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    sharedCatalog,
    {
      ...assumptions,
      values: { ...zeroValues, variablePatientCostCents: 100 }
    }
  );
  assert.equal(result.lines[0].directCostBreakdown.patientCostCents, 0);
  assert.equal(result.lines[0].promotional.sharedPlatformCostAllocatedCents, 2500);
  assert.deepEqual(
    result.possibleDuplicateCosts.map((duplicate) => duplicate.category),
    ['variablePatientCost']
  );
  assert.equal(result.possibleDuplicateCosts[0].justified, true);
});

test('supportPatientCost item_direct exige e contabiliza custo por paciente', () => {
  const supportCatalog = withCostModel('clinical_core', {
    supportCostPerPatientCents: 20
  });
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    supportCatalog,
    assumptions
  );
  assert.equal(result.lines[0].directCostBreakdown.supportCostCents, 500);
  const missingCatalog = withCostModel('clinical_core', {
    supportCostPerPatientCents: null
  });
  const blocks = validateModularCatalogForPublication(missingCatalog);
  assert.ok(
    blocks.some(
      (block) =>
        block.itemKey === 'clinical_core' &&
        block.field === 'supportCostPerPatientCents'
    )
  );
});

test('supportPatientCost shared ignora direto e usa somente premissa geral', () => {
  const supportCatalog = withCostModel('clinical_core', {
    supportCostPerPatientCents: 20
  });
  supportCatalog.modularCostSettings = {
    ...supportCatalog.modularCostSettings,
    ownership: {
      ...supportCatalog.modularCostSettings.ownership,
      supportPatientCost: 'shared'
    },
    ownershipJustifications: {
      supportPatientCost: 'Valor direto legado mantido somente para auditoria.'
    }
  };
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    supportCatalog,
    {
      ...assumptions,
      values: { ...zeroValues, supportPatientCostCents: 7 }
    }
  );
  assert.equal(result.lines[0].directCostBreakdown.supportCostCents, 0);
  assert.equal(result.lines[0].promotional.sharedPlatformCostAllocatedCents, 175);
});

test('supportPatientCost excluded ignora custo geral e direto', () => {
  const supportCatalog = withCostModel('clinical_core', {
    supportCostPerPatientCents: 20
  });
  supportCatalog.modularCostSettings = {
    ...supportCatalog.modularCostSettings,
    ownership: {
      ...supportCatalog.modularCostSettings.ownership,
      supportPatientCost: 'excluded'
    }
  };
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    supportCatalog,
    {
      ...assumptions,
      values: { ...zeroValues, supportPatientCostCents: 7 }
    }
  );
  assert.equal(result.lines[0].directCostBreakdown.supportCostCents, 0);
  assert.equal(result.lines[0].promotional.sharedPlatformCostAllocatedCents, 0);
});

test('otherVariableCost item_direct possui campo e parcela próprios', () => {
  const otherCatalog = withCostModel('clinical_core', {
    otherVariableCostCents: 321
  });
  otherCatalog.modularCostSettings = {
    ...otherCatalog.modularCostSettings,
    ownership: {
      ...otherCatalog.modularCostSettings.ownership,
      otherVariableCost: 'item_direct'
    }
  };
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    otherCatalog,
    {
      ...assumptions,
      values: { ...zeroValues, otherVariableCostCents: 999 }
    }
  );
  assert.equal(
    result.lines[0].directCostBreakdown.otherVariableCostCents,
    321
  );
  assert.equal(result.lines[0].promotional.sharedPlatformCostAllocatedCents, 0);
});

test('otherVariableCost shared ignora direto e usa somente premissa geral', () => {
  const otherCatalog = withCostModel('clinical_core', {
    otherVariableCostCents: 321
  });
  otherCatalog.modularCostSettings = {
    ...otherCatalog.modularCostSettings,
    ownership: {
      ...otherCatalog.modularCostSettings.ownership,
      otherVariableCost: 'shared'
    },
    ownershipJustifications: {
      otherVariableCost: 'Valor direto preservado para auditoria administrativa.'
    }
  };
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    otherCatalog,
    {
      ...assumptions,
      values: { ...zeroValues, otherVariableCostCents: 99 }
    }
  );
  assert.equal(result.lines[0].directCostBreakdown.otherVariableCostCents, 0);
  assert.equal(result.lines[0].promotional.sharedPlatformCostAllocatedCents, 99);
});

test('otherVariableCost excluded ignora custo geral e direto', () => {
  const otherCatalog = withCostModel('clinical_core', {
    otherVariableCostCents: 321
  });
  otherCatalog.modularCostSettings = {
    ...otherCatalog.modularCostSettings,
    ownership: {
      ...otherCatalog.modularCostSettings.ownership,
      otherVariableCost: 'excluded'
    }
  };
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    otherCatalog,
    {
      ...assumptions,
      values: { ...zeroValues, otherVariableCostCents: 99 }
    }
  );
  assert.equal(result.lines[0].directCostBreakdown.otherVariableCostCents, 0);
  assert.equal(result.lines[0].promotional.sharedPlatformCostAllocatedCents, 0);
});

test('zero explícito é aceito e null bloqueia custos diretos aplicáveis', () => {
  const explicitZero = withCostModel('clinical_core', {
    supportCostPerPatientCents: 0,
    otherVariableCostCents: 0
  });
  explicitZero.modularCostSettings = {
    ...explicitZero.modularCostSettings,
    ownership: {
      ...explicitZero.modularCostSettings.ownership,
      otherVariableCost: 'item_direct'
    }
  };
  const zeroBlocks = validateModularCatalogForPublication(explicitZero);
  assert.equal(
    zeroBlocks.some((block) =>
      ['supportCostPerPatientCents', 'otherVariableCostCents'].includes(
        String(block.field)
      )
    ),
    false
  );
  const missing = withCostModel('clinical_core', {
    supportCostPerPatientCents: null,
    otherVariableCostCents: null
  });
  missing.modularCostSettings = explicitZero.modularCostSettings;
  const missingFields = validateModularCatalogForPublication(missing)
    .map((block) => block.field);
  assert.ok(missingFields.includes('supportCostPerPatientCents'));
  assert.ok(missingFields.includes('otherVariableCostCents'));
});

test('custo negativo bloqueia publicação e não vira zero no motor', () => {
  const negative = withCostModel('clinical_core', {
    otherVariableCostCents: -1
  });
  negative.modularCostSettings = {
    ...negative.modularCostSettings,
    ownership: {
      ...negative.modularCostSettings.ownership,
      otherVariableCost: 'item_direct'
    }
  };
  const blocks = validateModularCatalogForPublication(negative);
  assert.ok(
    blocks.some(
      (block) =>
        block.code === 'NEGATIVE_COST' &&
        block.field === 'otherVariableCostCents'
    )
  );
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    negative,
    assumptions
  );
  assert.equal(result.promotional.directCostCents, null);
});

test('matriz canônica define aplicabilidade e exclui mensalidade do onboarding', () => {
  assert.deepEqual(MODULAR_COST_APPLICABILITY_BY_ITEM.onboarding, []);
  assert.equal(
    modularCostCategoryApplies('clinical_core', 'supportPatientCost'),
    true
  );
  assert.equal(
    modularCostCategoryApplies('financial_management', 'supportPatientCost'),
    false
  );
  assert.equal(
    modularCostCategoryApplies('additional_storage', 'otherVariableCost'),
    true
  );
  assert.equal(
    modularCostCategoryApplies(
      'additional_storage',
      'fixedMonthlyEligibleCost'
    ),
    false
  );
  for (const itemKey of [
    'clinical_core',
    'appointments_communication',
    'school_management'
  ]) {
    assert.ok(
      requiredDirectCostFieldsForItem(
        itemKey,
        catalog.modularCostSettings
      ).includes('supportCostPerPatientCents')
    );
  }
  assert.equal(
    requiredDirectCostFieldsForItem(
      'financial_management',
      catalog.modularCostSettings
    ).includes('supportCostPerPatientCents'),
    false
  );
});

test('custo compartilhado só entra quando uma funcionalidade aplicável foi selecionada', () => {
  const processingCatalog = withCostModel('financial_management', {
    processingCostPerUnitCents: 0
  });
  processingCatalog.modularCostSettings = {
    ...processingCatalog.modularCostSettings,
    ownership: {
      ...processingCatalog.modularCostSettings.ownership,
      processingCost: 'shared'
    }
  };
  const sharedAssumptions = {
    ...assumptions,
    values: { ...zeroValues, processingCostCents: 55 }
  };
  const withoutApplicableItem = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    processingCatalog,
    sharedAssumptions
  );
  assert.equal(
    withoutApplicableItem.promotional.sharedPlatformCostAllocatedCents,
    0
  );
  const withApplicableItem = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0], proposal().lines[2]] }),
    processingCatalog,
    sharedAssumptions
  );
  assert.equal(
    withApplicableItem.promotional.sharedPlatformCostAllocatedCents,
    55
  );
});

test('requiredDrivers aceita ordem diferente sem aceitar ausentes extras ou duplicados', () => {
  const config = completeDriverConfig('clinical_core');
  config.requiredDrivers.reverse();
  assert.equal(hasExactRequiredDrivers('clinical_core', config), true);
  const reordered = withCostModel('clinical_core', { driverConfig: config });
  assert.equal(
    validateModularCatalogForPublication(reordered).some(
      (block) => block.code === 'DRIVER_CONFIG_INVALID'
    ),
    false
  );
  assert.equal(
    hasExactRequiredDrivers('clinical_core', {
      ...config,
      requiredDrivers: [...config.requiredDrivers, config.requiredDrivers[0]]
    }),
    false
  );
  assert.equal(
    hasExactRequiredDrivers('clinical_core', {
      ...config,
      requiredDrivers: config.requiredDrivers.slice(1)
    }),
    false
  );
});

test('matriz de propriedade rejeita chave extra e chave ausente', () => {
  const extra = structuredClone(catalog.modularCostSettings) as any;
  extra.ownership.unexpectedCost = 'shared';
  assert.equal(isValidModularCostSettings(extra), false);
  const missing = structuredClone(catalog.modularCostSettings) as any;
  delete missing.ownership.supportPatientCost;
  assert.equal(isValidModularCostSettings(missing), false);
  assert.ok(
    validateModularCatalogForPublication({
      ...catalog,
      modularCostSettings: extra
    }).some((block) => block.code === 'COST_SETTINGS_INVALID')
  );
});

test('clinical_core reserva 1000 MB na faixa ate 10', () => {
  const storageCatalog = withCostModel('clinical_core', {
    storageCostPerGbCents: 100,
    egressCostPerGbCents: 0
  });
  const result = calculateSalesModularProposal(
    proposal({
      patientQuantity: 8,
      expectedPatientQuantity12Months: 8,
      basePackageTierId: 'core-up_to_10',
      lines: [{ itemKey: 'clinical_core', tierId: 'core-up_to_10', quantity: 8 }]
    }),
    storageCatalog,
    assumptions
  );
  assert.equal(result.basePackage.includedStorageMb, 1000);
  assert.equal(result.lines[0].directCostBreakdown.includedStorageGb, 1000 / 1024);
  assert.equal(result.lines[0].directCostBreakdown.storageCostCents, 59);
});

test('clinical_core reserva 2500 MB na faixa ate 25', () => {
  const storageCatalog = withCostModel('clinical_core', {
    storageCostPerGbCents: 100,
    egressCostPerGbCents: 0
  });
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    storageCatalog,
    assumptions
  );
  assert.equal(result.basePackage.includedStorageMb, 2500);
  assert.equal(result.lines[0].directCostBreakdown.includedStorageGb, 2500 / 1024);
});

test('percentual de utilizacao usa capacidade reservada e nao pacientes atuais', () => {
  const storageCatalog = withCostModel('clinical_core', {
    storageCostPerGbCents: 100,
    egressCostPerGbCents: 0
  });
  const result = calculateSalesModularProposal(
    proposal({
      patientQuantity: 1,
      expectedPatientQuantity12Months: 1,
      basePackageTierId: 'core-up_to_25',
      lines: [{ itemKey: 'clinical_core', tierId: 'core-up_to_25', quantity: 1 }]
    }),
    storageCatalog,
    assumptions
  );
  assert.equal(
    result.lines[0].directCostBreakdown.estimatedUsedStorageGb,
    (2500 / 1024) * 0.6
  );
});

test('egress usa multiplicador separado do armazenamento', () => {
  const storageCatalog = withCostModel('clinical_core', {
    storageCostPerGbCents: 0,
    egressCostPerGbCents: 100
  });
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    storageCatalog,
    assumptions
  );
  const used = (2500 / 1024) * 0.6;
  assert.equal(result.lines[0].directCostBreakdown.estimatedEgressGb, used * 2);
  assert.equal(
    result.lines[0].directCostBreakdown.egressCostCents,
    Math.round(used * 2 * 100)
  );
});

test('armazenamento adicional usa GB comprados, utilizacao e egress', () => {
  const storageCatalog = withCostModel('additional_storage', {
    storageCostPerGbCents: 100,
    egressCostPerGbCents: 50
  });
  const result = calculateSalesModularProposal(
    proposal({
      lines: [
        proposal().lines[0],
        { itemKey: 'additional_storage', tierId: 'storage-gb_5', quantity: 2 }
      ]
    }),
    storageCatalog,
    assumptions
  );
  const line = result.lines.find((candidate) => candidate.itemKey === 'additional_storage')!;
  assert.equal(line.directCostBreakdown.includedStorageGb, 10);
  assert.equal(line.directCostBreakdown.estimatedUsedStorageGb, 6);
  assert.equal(line.directCostBreakdown.estimatedEgressGb, 12);
  assert.equal(line.directCostBreakdown.storageCostCents, 600);
  assert.equal(line.directCostBreakdown.egressCostCents, 600);
});

test('agenda calcula consultas e quantidade real de notificacoes', () => {
  const agendaCatalog = withCostModel(
    'appointments_communication',
    {
      directCostPerUsageUnitCents: 4,
      notificationCostPerUnitCents: 3
    },
    {
      monthlyAppointments: 100,
      remindersPerAppointment: 2,
      internalNotifications: 10,
      emails: 5,
      webPushNotifications: 5
    }
  );
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0], proposal().lines[1]] }),
    agendaCatalog,
    assumptions
  );
  const line = result.lines.find((candidate) => candidate.itemKey === 'appointments_communication')!;
  assert.equal(line.directCostBreakdown.usageCostCents, 400);
  assert.equal(line.directCostBreakdown.notificationCostCents, 660);
});

test('TISS calcula custo pela quantidade de guias da proposta', () => {
  const tissCatalog = withCostModel(
    'insurance_tiss',
    { directCostPerUsageUnitCents: 2, processingCostPerUnitCents: 0 },
    { tissBatches: 0, tissXmlDocuments: 0, tissDocuments: 0, expectedStorageGb: 0 }
  );
  const result = calculateSalesModularProposal(
    proposal({
      lines: [
        proposal().lines[0],
        { itemKey: 'insurance_tiss', tierId: 'insurance-up_to_500', quantity: 240 }
      ]
    }),
    tissCatalog,
    assumptions
  );
  const line = result.lines.find((candidate) => candidate.itemKey === 'insurance_tiss')!;
  assert.equal(line.resolvedDrivers.tissGuides?.value, 240);
  assert.equal(line.directCostBreakdown.usageCostCents, 480);
});

test('escolar usa somente pacientes com vinculo escolar', () => {
  const schoolCatalog = withCostModel(
    'school_management',
    { directCostPerPatientCents: 100, processingCostPerUnitCents: 0, notificationCostPerUnitCents: 0 },
    {
      schoolPatients: 3,
      schoolMeetings: 0,
      schoolParticipants: 0,
      schoolDocuments: 0,
      schoolNotifications: 0,
      expectedStorageGb: 0
    }
  );
  const result = calculateSalesModularProposal(
    proposal({
      lines: [proposal().lines[0], { itemKey: 'school_management', tierId: 'school-up_to_25', quantity: 17 }]
    }),
    schoolCatalog,
    assumptions
  );
  const line = result.lines.find((candidate) => candidate.itemKey === 'school_management')!;
  assert.equal(line.directCostBreakdown.patientCostCents, 300);
});

test('ABA calcula sessoes e registros por milhar', () => {
  const abaCatalog = withCostModel(
    'clinical_core',
    { directCostPerUsageUnitCents: 0 },
    {
      monthlyClinicalSessions: 0,
      monthlyAbaSessions: 10,
      monthlyAbaRecords: 2000,
      generatedDocuments: 0
    },
    { monthlyAbaSessions: 50, monthlyAbaRecords: 30, generatedDocuments: 0 }
  );
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0]] }),
    abaCatalog,
    assumptions
  );
  assert.equal(result.lines[0].directCostBreakdown.usageCostCents, 560);
});

test('implantacao calcula horas e custo extraordinario uma unica vez', () => {
  const onboardingCatalog = withCostModel(
    'onboarding',
    { onboardingCostCents: 0 },
    {
      onboardingConfigurationHours: 2,
      onboardingTrainingHours: 3,
      onboardingImportHours: 4
    },
    { onboardingHours: 1000 }
  );
  const input = proposal({
    lines: [
      proposal().lines[0],
      { itemKey: 'onboarding', quantity: 1, customOneTimeAmountCents: 20000 }
    ],
    driverOverrides: {
      onboarding: {
        extraordinaryOnboardingCostCents: {
          value: 500,
          source: 'manual',
          sourceDetail: 'Custo extraordinario do teste',
          effectiveAt: '2026-07-27T00:00:00.000Z',
          version: 1
        }
      }
    }
  });
  const result = calculateSalesModularProposal(input, onboardingCatalog, assumptions);
  assert.equal(result.oneTimeDirectCostCents, 9500);
  assert.equal(result.horizons['12'].oneTimeRevenueCents, 20000);
});

test('driver indisponivel permanece Dados insuficientes', () => {
  const unavailableAgenda = withCostModel(
    'appointments_communication',
    { directCostPerUsageUnitCents: 1, notificationCostPerUnitCents: 1 },
    { monthlyAppointments: 10, remindersPerAppointment: 1, internalNotifications: 0, emails: 0, webPushNotifications: 0 }
  );
  unavailableAgenda.items.find((item) => item.itemKey === 'appointments_communication')!
    .costModel!.driverConfig.profiles.standard.monthlyAppointments = {
      value: null,
      source: 'unavailable',
      sourceDetail: 'Sem medicao disponivel',
      effectiveAt: '2026-07-27T00:00:00.000Z',
      version: 1
    };
  const result = calculateSalesModularProposal(
    proposal({ lines: [proposal().lines[0], proposal().lines[1]] }),
    unavailableAgenda,
    assumptions
  );
  assert.ok(result.missingDrivers.some((missing) => missing.driver === 'monthlyAppointments'));
  assert.equal(result.promotional.directCostCents, null);
});

test('preserva origens actual calculated estimated e manual', () => {
  for (const source of ['actual', 'calculated', 'estimated', 'manual'] as const) {
    const sourceCatalog = withCostModel('clinical_core', {});
    sourceCatalog.items.find((item) => item.itemKey === 'clinical_core')!
      .costModel!.driverConfig.profiles.standard.monthlyClinicalSessions = {
        value: 1,
        source,
        sourceDetail: `Origem ${source} auditavel`,
        effectiveAt: '2026-07-27T00:00:00.000Z',
        version: 2
      };
    const result = calculateSalesModularProposal(
      proposal({ lines: [proposal().lines[0]] }),
      sourceCatalog,
      assumptions
    );
    assert.equal(result.lines[0].resolvedDrivers.monthlyClinicalSessions?.source, source);
  }
});

test('perfil intensivo usa 100 por cento e multiplicador cinco', () => {
  const intensiveCatalog = withCostModel('clinical_core', {
    storageCostPerGbCents: 0,
    egressCostPerGbCents: 100
  });
  const result = calculateSalesModularProposal(
    proposal({ usageProfile: 'intensive', lines: [proposal().lines[0]] }),
    intensiveCatalog,
    assumptions
  );
  const included = 2500 / 1024;
  assert.equal(result.lines[0].directCostBreakdown.estimatedUsedStorageGb, included);
  assert.equal(result.lines[0].directCostBreakdown.estimatedEgressGb, included * 5);
});

test('perfil personalizado exige e aceita drivers manuais versionados', () => {
  const customCatalog = withCostModel('clinical_core', {
    storageCostPerGbCents: 0,
    egressCostPerGbCents: 0
  });
  const config = customCatalog.items.find((item) => item.itemKey === 'clinical_core')!.costModel!.driverConfig;
  const overrides = Object.fromEntries(
    [...config.requiredDrivers, 'storageUtilizationBasisPoints', 'expectedEgressMultiplier'].map((driver) => [
      driver,
      {
        value: driver === 'storageUtilizationBasisPoints' ? 7500 : driver === 'expectedEgressMultiplier' ? 3 : 1,
        source: 'manual',
        sourceDetail: 'Valor personalizado informado pelo owner',
        effectiveAt: '2026-07-27T00:00:00.000Z',
        version: 3
      }
    ])
  );
  const result = calculateSalesModularProposal(
    proposal({
      usageProfile: 'custom',
      lines: [proposal().lines[0]],
      driverOverrides: { clinical_core: overrides }
    }),
    customCatalog,
    assumptions
  );
  assert.equal(result.missingDrivers.length, 0);
  assert.equal(result.lines[0].resolvedDrivers.expectedEgressMultiplier?.value, 3);
});

test('soma das categorias de cada linha coincide com o consolidado', () => {
  const result = calculateSalesModularProposal(proposal(), catalog, assumptions);
  for (const field of [
    'fixedCostCents',
    'patientCostCents',
    'usageCostCents',
    'storageCostCents',
    'egressCostCents',
    'notificationCostCents',
    'otherVariableCostCents',
    'supportCostCents',
    'operationalCostCents'
  ] as const) {
    assert.equal(
      result.lines.reduce((sum, line) => sum + Number(line.directCostBreakdown[field]), 0),
      result.promotional.directCostBreakdown[field]
    );
  }
  assert.equal(result.totalsReconciled, true);
});

test('publicacao e bloqueada por duplicidade sem justificativa', () => {
  const duplicateCatalog = withCostModel('clinical_core', {
    directCostPerPatientCents: 100
  });
  duplicateCatalog.modularCostSettings = {
    ...duplicateCatalog.modularCostSettings,
    ownership: {
      ...duplicateCatalog.modularCostSettings.ownership,
      variablePatientCost: 'shared'
    },
    ownershipJustifications: {}
  };
  const blocks = validateModularCatalogForPublication(
    duplicateCatalog,
    { ...zeroValues, variablePatientCostCents: 100 }
  );
  assert.ok(blocks.some((block) => block.code === 'POSSIBLE_DUPLICATE_COST'));
});

test('duplicidade com justificativa administrativa válida pode prosseguir', () => {
  const justifiedCatalog = withCostModel('clinical_core', {
    otherVariableCostCents: 100
  });
  justifiedCatalog.modularCostSettings = {
    ...justifiedCatalog.modularCostSettings,
    ownership: {
      ...justifiedCatalog.modularCostSettings.ownership,
      otherVariableCost: 'shared'
    },
    ownershipJustifications: {
      otherVariableCost:
        'Valor direto histórico preservado para rastreabilidade administrativa.'
    }
  };
  const blocks = validateModularCatalogForPublication(justifiedCatalog);
  assert.equal(
    blocks.some((block) => block.code === 'POSSIBLE_DUPLICATE_COST'),
    false
  );
});

let passed = 0;
for (const { name, fn } of tests) {
  try {
    fn();
    passed += 1;
    console.log(`ok - ${name}`);
  } catch (error) {
    console.error(`not ok - ${name}`);
    throw error;
  }
}

console.log(`sales modular proposal tests passed: ${passed}/${tests.length}`);
